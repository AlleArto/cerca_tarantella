# CercaTarantella

> Applicazione che cerca il testo di una canzone tramite ricerca utilizzando l'API di MusixMatch

# Membri della Sagrada Piccio

Gurjyot Wanga, Alessandro Artoni, Alessandro Grasselli, Francesco Castorini, Aurora Montanino, Ilenia Sacchetti, Marco Vezzali, Alberto Boni, Andrea Oleari, Davide Rabotti, Riccardo Menozzi, Mena Istafanous, Lorenzo Sarperi 

## Quick Start

```bash
# Installare le dipendenze
npm install

# Eseguire l'app su localhost:3000
npm start
```
## App in funzione

Puoi visitare la versione online in funzione sul seguente link : www.musedia.it

### Version

1.0.0

### License

This project is licensed under the MIT License
